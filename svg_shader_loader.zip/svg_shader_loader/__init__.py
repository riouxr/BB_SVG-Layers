bl_info = {
    "name": "SVG Shader Loader",
    "author": "Custom",
    "version": (1, 9, 0),
    "blender": (4, 0, 0),
    "location": "View3D > N-Panel > Shaders",
    "description": "Load SVG, assign Master-based materials by prefix, rotate & stack layers",
    "category": "Material",
}

import bpy
import xml.etree.ElementTree as ET
import math
import re
import random
import os
import hashlib

# ─── SVG Helpers ──────────────────────────────────────────────────────────────

def hex_to_linear(hex_color):
    hex_color = hex_color.strip().lstrip("#")
    if len(hex_color) == 3:
        hex_color = "".join(c * 2 for c in hex_color)
    r = int(hex_color[0:2], 16) / 255.0
    g = int(hex_color[2:4], 16) / 255.0
    b = int(hex_color[4:6], 16) / 255.0
    def s2l(c):
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return (s2l(r), s2l(g), s2l(b), 1.0)

def _fill_from_style(style):
    m = re.search(r'fill\s*:\s*(#[0-9a-fA-F]{3,6})', style)
    return m.group(1) if m else None

def get_fill_color(element):
    fill = element.get("fill", "")
    if fill and fill.lower() not in ("", "none"):
        return fill
    style = element.get("style", "")
    if style:
        return _fill_from_style(style)
    return None

def parse_svg(svg_path):
    tree = ET.parse(svg_path)
    root = tree.getroot()
    prefix_color = {}
    svg_id_order = []
    for elem in root.iter():
        elem_id = elem.get("id", "")
        if "." not in elem_id:
            continue
        svg_id_order.append(elem_id)
        prefix = elem_id.split(".")[0]
        if prefix not in prefix_color:
            color = get_fill_color(elem)
            if color:
                prefix_color[prefix] = color
    return prefix_color, svg_id_order

def set_color_in_nodetree(node_tree, linear_color):
    nodes = node_tree.nodes
    if "Color" in nodes:
        n = nodes["Color"]
        if n.outputs and hasattr(n.outputs[0], "default_value"):
            n.outputs[0].default_value = linear_color
            return
    for n in nodes:
        if n.type == "RGB":
            n.outputs[0].default_value = linear_color
            return
    for n in nodes:
        if n.type == "BSDF_PRINCIPLED":
            n.inputs["Base Color"].default_value = linear_color
            return
    for n in nodes:
        for inp in n.inputs:
            if inp.name == "Color" and inp.type == "RGBA":
                inp.default_value = linear_color
                return

def set_mapping_rotation_z(node_tree):
    for n in node_tree.nodes:
        if n.type == "MAPPING":
            n.inputs["Rotation"].default_value[2] = math.radians(random.uniform(0, 360))
            return

def get_or_create_material(prefix, linear_color, master_mat):
    if prefix in bpy.data.materials:
        mat = bpy.data.materials[prefix]
    else:
        mat = master_mat.copy()
        mat.name = prefix
    if mat.use_nodes:
        set_color_in_nodetree(mat.node_tree, linear_color)
        set_mapping_rotation_z(mat.node_tree)
    return mat

def assign_material(obj, mat):
    obj.data.materials.clear()
    obj.data.materials.append(mat)

def svg_id_from_obj_name(obj_name):
    return re.sub(r'\.\d{3,}$', '', obj_name)

def get_user_library_path():
    prefs = bpy.context.preferences
    libs = prefs.filepaths.asset_libraries
    for lib in libs:
        if lib.name.lower() == "user library":
            return bpy.path.abspath(lib.path)
    if libs:
        return bpy.path.abspath(libs[0].path)
    return None

def _ensure_catalog(lib_root, catalog_name):
    cats_path = os.path.join(lib_root, "blender_assets.cats.txt")
    h = hashlib.md5(catalog_name.encode()).hexdigest()
    uid = f"{h[:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"
    entry = f"{uid}:{catalog_name}:{catalog_name}\n"
    existing = ""
    if os.path.exists(cats_path):
        with open(cats_path, "r", encoding="utf-8") as f:
            existing = f.read()
    if uid not in existing:
        with open(cats_path, "a", encoding="utf-8") as f:
            if not existing:
                f.write("VERSION 1\n")
            f.write(entry)
    return uid

def mark_and_export_materials(materials, catalog_name="Paper"):
    lib_root = get_user_library_path()
    if lib_root is None:
        return False, "No asset library configured in Preferences > File Paths > Asset Libraries."

    uid = _ensure_catalog(lib_root, catalog_name)

    for mat in materials:
        # Use the same operator Blender uses on right-click
        with bpy.context.temp_override(id=mat):
            bpy.ops.asset.mark()
        mat.asset_data.catalog_id = uid
        mat.preview_ensure()

    # Force synchronous preview render for all assets then write once
    bpy.ops.wm.previews_ensure()

    target_dir = os.path.join(lib_root, catalog_name)
    os.makedirs(target_dir, exist_ok=True)
    target_blend = os.path.join(target_dir, f"{catalog_name}.blend")

    bpy.data.libraries.write(
        target_blend,
        set(materials),
        fake_user=True,
        compress=False,
    )

    return True, target_blend


# ─── Operator ─────────────────────────────────────────────────────────────────

class SHADERS_OT_load_svg(bpy.types.Operator):
    bl_idname  = "shaders.load_svg"
    bl_label   = "Load SVG"
    bl_options = {"REGISTER", "UNDO"}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_glob: bpy.props.StringProperty(default="*.svg", options={"HIDDEN"})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        svg_path = self.filepath

        master_mat = bpy.data.materials.get("Master")
        if master_mat is None:
            self.report({"ERROR"}, "No material named 'Master' found.")
            return {"CANCELLED"}

        try:
            prefix_color, svg_id_order = parse_svg(svg_path)
        except Exception as exc:
            self.report({"ERROR"}, f"SVG parse error: {exc}")
            return {"CANCELLED"}

        if not prefix_color:
            self.report({"WARNING"}, "No matching layers found.")
            return {"CANCELLED"}

        # Snapshot before import
        before_objects = set(obj.name for obj in bpy.data.objects)
        before_materials = set(mat.name for mat in bpy.data.materials)

        bpy.ops.import_curve.svg(filepath=svg_path)

        new_objects = [o for o in bpy.data.objects if o.name not in before_objects]

        if not new_objects:
            self.report({"ERROR"}, "SVG import produced no objects.")
            return {"CANCELLED"}

        # Delete any materials the SVG importer auto-created
        svg_auto_mats = [m for m in bpy.data.materials if m.name not in before_materials]
        for mat in svg_auto_mats:
            bpy.data.materials.remove(mat)

        # Convert curves to meshes
        bpy.ops.object.select_all(action='DESELECT')
        for obj in new_objects:
            obj.select_set(True)
        context.view_layer.objects.active = new_objects[0]
        bpy.ops.object.convert(target='MESH')

        new_meshes = [o for o in bpy.data.objects if o.name not in before_objects and o.type == 'MESH']

        # Rotate 90 X and apply
        bpy.ops.object.select_all(action='DESELECT')
        for obj in new_meshes:
            obj.select_set(True)
        context.view_layer.objects.active = new_meshes[0]
        bpy.ops.transform.rotate(value=math.radians(90), orient_axis='X')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        # Smart UV project per mesh
        for obj in new_meshes:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.uv.smart_project()
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')

        # Build id->obj map
        id_to_obj = {}
        for obj in new_meshes:
            sid = svg_id_from_obj_name(obj.name)
            id_to_obj[sid] = obj

        # Y offset stack
        matched_ids = [sid for sid in svg_id_order if sid in id_to_obj]
        n = len(matched_ids)
        for rank, sid in enumerate(matched_ids):
            id_to_obj[sid].location.y = (rank - (n - 1)) * 0.02

        # Create and assign materials
        new_mats = []
        created = set()
        for obj in new_meshes:
            sid = svg_id_from_obj_name(obj.name)
            if "." not in sid:
                continue
            prefix = sid.split(".")[0]
            if prefix not in prefix_color:
                continue
            mat = get_or_create_material(prefix, hex_to_linear(prefix_color[prefix]), master_mat)
            assign_material(obj, mat)
            if prefix not in created:
                new_mats.append(mat)
                created.add(prefix)

        # Mark as assets and export to User Library / Paper
        ok, result = mark_and_export_materials(new_mats, catalog_name="Paper")
        if ok:
            self.report({"INFO"}, f"Done — {n} layer(s), {len(created)} material(s) exported to {result}")
        else:
            self.report({"WARNING"}, f"Done — materials created but library export failed: {result}")

        return {"FINISHED"}


# ─── Panel ────────────────────────────────────────────────────────────────────

class SHADERS_PT_panel(bpy.types.Panel):
    bl_label       = "Shaders"
    bl_idname      = "SHADERS_PT_panel"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "Shaders"

    def draw(self, context):
        self.layout.operator("shaders.load_svg", icon="FILE_IMAGE")


# ─── Registration ─────────────────────────────────────────────────────────────

classes = (SHADERS_OT_load_svg, SHADERS_PT_panel)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
